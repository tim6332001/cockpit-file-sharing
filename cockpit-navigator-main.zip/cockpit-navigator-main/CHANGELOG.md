## Cockpit Navigator 0.5.8-2

* Add file and coreutils dependencies.