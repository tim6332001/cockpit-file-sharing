import React from 'react'

const MultiPartStep = ({steps}) => {

    return (
        <div>
            {steps}
        </div>
    )
};

export default MultiPartStep;