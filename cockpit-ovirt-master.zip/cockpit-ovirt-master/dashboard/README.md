This package provides a basic skeleton to initialize a basic ovirt dashboard for cockpit
