import React from 'react';

export const ModelContext = React.createContext(undefined);
