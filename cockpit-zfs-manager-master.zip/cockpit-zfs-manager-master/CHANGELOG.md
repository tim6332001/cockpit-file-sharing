## Cockpit ZFS Manager 1.3.0-1

* Add znapzend Replication Task support at the dataset level.
* Enhance methods of managing dropdown menus.
* Add Dataset Permissions as a dropdown action.
* Change default disk selector name to prefer aliases.

## Cockpit ZFS Manager 1.3.0-2

* Add EL8 Packaging.

## Cockpit ZFS Manager 1.3.0-3

* Rebuild Packages.